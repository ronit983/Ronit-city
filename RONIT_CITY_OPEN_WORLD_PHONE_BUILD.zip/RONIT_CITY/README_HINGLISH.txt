RONIT CITY - OPEN WORLD 2D ANDROID GAME

GAME FEATURES
- Large 3600 x 2800 scrolling open-world city
- Colourful districts, shops, buildings, parks, trees and roads
- 70 wandering NPCs with simple independent movement
- 30 moving traffic vehicles
- Player walking and vehicle driving/exit
- Mission markers, rewards, cash and score
- Mini-map, joystick, action button and pause menu
- Offline gameplay; no login or internet required after install

PHONE-ONLY APK BUILD
This project includes .github/workflows/build-apk.yml. Upload the project contents to a GitHub repository from your phone, then open Actions and run "Build RONIT CITY APK". Download the APK from the completed run's Artifacts section.

APK SIZE
The game is designed around actual gameplay and assets, not artificial file padding. A 10 MB APK size does not automatically mean better graphics or gameplay. This prototype may build smaller than 10 MB; adding real sprite art, music, voice and more content can increase size naturally.

This is a playable prototype foundation, not a finished commercial game. Test on the target phone before sharing.
